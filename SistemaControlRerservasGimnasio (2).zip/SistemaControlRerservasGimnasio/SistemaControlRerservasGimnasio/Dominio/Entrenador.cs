﻿namespace Dominio
{
    public class Entrenador : Persona
    {
        public int Id { get; set; }
    }
}
