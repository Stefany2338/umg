﻿namespace Dominio_
{
    public class Class1
    {

    }
}
